<!-- Footer Section -->
<div id="clearfloat"></div>

<section class="tp-overall-footer">
	<section class="tp-footer">
		<p><span class="tp-icon fa-check-circle"></span> Designed by <a href="mailto:me@triadiprabowo.com">Triadi Prabowo</a>, Powered by tpScript Bootstrap</p>
	</section>
</section>