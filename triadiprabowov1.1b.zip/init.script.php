<!-- Init Script Because of Deep Link Routing -->
<script src="res/js/jquery-1.10.2.js"></script>		
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
<script src="res/js/tp-core.js"></script>
<!-- End Init -->